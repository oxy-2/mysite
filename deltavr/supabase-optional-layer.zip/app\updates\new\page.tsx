"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { createPost } from "@/app/actions";
import { getSupabaseBrowserClient } from "@/lib/supabase/client";

export default function NewUpdatePage() {
  const supabase = getSupabaseBrowserClient();
  const [role, setRole] = useState<string | null>(null);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    if (!supabase) {
      setChecking(false);
      return;
    }
    supabase.auth.getUser().then(async ({ data }) => {
      if (!data.user) {
        setChecking(false);
        return;
      }
      const { data: profile } = await supabase
        .from("profiles")
        .select("role")
        .eq("id", data.user.id)
        .maybeSingle();
      setRole(profile?.role ?? "viewer");
      setChecking(false);
    });
  }, [supabase]);

  if (checking) {
    return (
      <section className="section">
        <div className="container">
          <div className="empty-note">checking permissions…</div>
        </div>
      </section>
    );
  }

  if (supabase && role === null) {
    return (
      <section className="section">
        <div className="container" style={{ maxWidth: 640 }}>
          <div className="empty-note">
            sign in with google first — then, if you're on the allow-list
            (owner/collaborator), you can post updates here.
          </div>
        </div>
      </section>
    );
  }

  if (role && !["owner", "collaborator"].includes(role)) {
    return (
      <section className="section">
        <div className="container" style={{ maxWidth: 640 }}>
          <div className="empty-note">
            your account doesn't have posting permission. ask oxy to flip you to
            collaborator in the profiles table.
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="section">
      <div className="container" style={{ maxWidth: 640 }}>
        <div className="section-label">
          <span className="red-dot" />
          <span>07 // new update</span>
        </div>

        <form action={createPost}>
        <div className="field">
          <label>title</label>
          <input name="title" placeholder="controller pcb done. finally." required />
        </div>

        <div className="field">
          <label>cover image url (optional)</label>
          <input name="cover" placeholder="https://…/screenshot.png" />
        </div>

        <div className="field">
          <label>body (markdown / mdx)</label>
          <textarea
            name="content"
            required
            defaultValue={""}
            placeholder={"routed everything today…\n\n![pic](url)\n\n- tmr stick works\n- hall triggers read clean"}
          />
        </div>

        <div style={{ display: "flex", gap: 12 }}>
          <button type="submit" className="btn btn-black">
            publish update →
          </button>
          <Link href="/updates" className="btn btn-ghost">
            cancel
          </Link>
        </div>
        </form>
      </div>
    </section>
  );
}
