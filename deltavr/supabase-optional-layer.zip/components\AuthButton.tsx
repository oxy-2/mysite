"use client";

import { useEffect, useState } from "react";
import { getSupabaseBrowserClient, BASE_PATH } from "@/lib/supabase/client";

export default function AuthButton() {
  const supabase = getSupabaseBrowserClient();
  const [user, setUser] = useState<{
    email: string;
    name: string;
  } | null>(null);

  useEffect(() => {
    if (!supabase) return;
    supabase.auth.getUser().then(async ({ data }) => {
      if (!data.user) return;
      const { data: profile } = await supabase
        .from("profiles")
        .select("username")
        .eq("id", data.user.id)
        .maybeSingle();
      setUser({
        email: data.user.email ?? "",
        name:
          (profile?.username as string) ??
          data.user.email?.split("@")[0] ??
          "you",
      });
    });
    const { data: sub } = supabase.auth.onAuthStateChange(() => {
      window.location.reload();
    });
    return () => sub.subscription.unsubscribe();
  }, [supabase]);

  if (!supabase) return null;

  async function signIn() {
    await supabase!.auth.signInWithOAuth({
      provider: "google",
      options: {
        redirectTo: `${window.location.origin}${BASE_PATH}/auth/callback`,
      },
    });
  }

  async function signOut() {
    await supabase!.auth.signOut();
  }

  if (!user) {
    return (
      <button className="btn-text" onClick={signIn} title="sign in with google">
        sign in
      </button>
    );
  }

  return (
    <span style={{ display: "inline-flex", gap: 6, alignItems: "center" }}>
      <span className="dim" style={{ fontSize: 10 }}>@{user.name}</span>
      <button className="btn-text" onClick={signOut}>
        out
      </button>
    </span>
  );
}
