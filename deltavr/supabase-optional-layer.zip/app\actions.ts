"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { getSupabaseServerClient } from "@/lib/supabase/server";

function slugify(s: string): string {
  return s
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, "")
    .trim()
    .replace(/\s+/g, "-")
    .slice(0, 60);
}

async function requireRole() {
  const supabase = await getSupabaseServerClient();
  if (!supabase) throw new Error("supabase not configured");
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error("not signed in");
  const { data: profile } = await supabase
    .from("profiles")
    .select("role")
    .eq("id", user.id)
    .maybeSingle();
  const role = profile?.role ?? "viewer";
  if (!["owner", "collaborator"].includes(role)) {
    throw new Error("you don't have permission to post");
  }
  return { supabase, userId: user.id };
}

export async function createPost(formData: FormData) {
  const { supabase } = await requireRole();

  const title = String(formData.get("title") ?? "").trim();
  const content = String(formData.get("content") ?? "").trim();
  const cover = String(formData.get("cover") ?? "").trim();
  if (!title || !content) throw new Error("title + content required");

  const base = slugify(title) || "update";
  let slug = base;
  for (let i = 2; ; i++) {
    const { data: existing } = await supabase
      .from("posts")
      .select("id")
      .eq("slug", slug)
      .maybeSingle();
    if (!existing) break;
    slug = `${base}-${i}`;
  }

  const excerpt =
    content.replace(/[#*`>\[\]!]/g, "").slice(0, 180).trim() + "…";

  const { error } = await supabase.from("posts").insert({
    slug,
    title,
    content_mdx: content,
    excerpt,
    cover_image: cover || null,
    status: "published",
    published_at: new Date().toISOString(),
  });
  if (error) throw new Error(error.message);

  revalidatePath("/updates");
  revalidatePath("/");
  redirect(`/updates/${slug}`);
}

export async function addComment(postId: string, formData: FormData) {
  const supabase = await getSupabaseServerClient();
  if (!supabase) throw new Error("supabase not configured");
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error("sign in to comment");

  const content = String(formData.get("content") ?? "").trim();
  if (!content) return;

  await supabase.from("comments").insert({
    post_id: postId,
    author_id: user.id,
    content,
  });
  revalidatePath("/updates");
}
