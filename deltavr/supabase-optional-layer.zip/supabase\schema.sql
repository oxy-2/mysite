-- deltavr demo site — supabase schema
-- run this in the supabase SQL editor after creating a project

-- profiles (extends auth.users)
create table if not exists profiles (
  id uuid primary key references auth.users on delete cascade,
  username text unique not null,
  role text not null default 'viewer' check (role in ('owner','collaborator','viewer')),
  avatar_url text,
  created_at timestamptz default now()
);

-- posts (build log / updates)
create table if not exists posts (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  title text not null,
  content_mdx text not null,
  excerpt text,
  cover_image text,
  author_id uuid references profiles(id),
  status text not null default 'published' check (status in ('draft','published')),
  published_at timestamptz,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- comments
create table if not exists comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references posts(id) on delete cascade,
  author_id uuid not null references profiles(id) on delete cascade,
  author_name text,
  content text not null,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- likes (posts or comments)
create table if not exists likes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  target_type text not null check (target_type in ('post','comment')),
  -- for posts this is the post uuid; for comments, comment uuid.
  -- views uses slug strings instead — different table on purpose.
  target_id text not null,
  created_at timestamptz default now(),
  unique(user_id, target_type, target_id)
);

-- views (unique per session)
create table if not exists views (
  id uuid primary key default gen_random_uuid(),
  target_type text not null check (target_type in ('post','page')),
  target_id text not null,
  session_id text not null default 'anon',
  created_at timestamptz default now(),
  unique(target_type, target_id, session_id)
);

-- row level security
alter table profiles enable row level security;
alter table posts enable row level security;
alter table comments enable row level security;
alter table likes enable row level security;
alter table views enable row level security;

-- profiles: public read, self insert/update
create policy "public read profiles" on profiles for select using (true);
create policy "self insert profile" on profiles for insert with check (auth.uid() = id);
create policy "self update profile" on profiles for update using (auth.uid() = id);

-- posts: public read published; owner/collaborator write
create policy "public read published posts" on posts for select using (status = 'published');
create policy "staff insert posts" on posts for insert with check (
  exists (select 1 from profiles where id = auth.uid() and role in ('owner','collaborator'))
);
create policy "author update own posts" on posts for update
  using (exists (select 1 from profiles where id = auth.uid() and (author_id = auth.uid() or role = 'owner')));
create policy "author delete own posts" on posts for delete
  using (exists (select 1 from profiles where id = auth.uid() and (author_id = auth.uid() or role = 'owner')));

-- comments: public read, auth write own
create policy "public read comments" on comments for select using (true);
create policy "auth insert comments" on comments for insert with check (auth.uid() = author_id);
create policy "author update own comments" on comments for update using (auth.uid() = author_id);
create policy "author delete own comments" on comments for delete using (auth.uid() = author_id);

-- likes: public read, auth manage own
create policy "public read likes" on likes for select using (true);
create policy "auth insert likes" on likes for insert with check (auth.uid() = user_id);
create policy "self delete likes" on likes for delete using (auth.uid() = user_id);

-- views: anyone records, public read counts
create policy "anyone insert views" on views for insert with check (true);
create policy "public read views" on views for select using (true);

-- realtime for live comments/likes/views
alter publication supabase_realtime add table comments;
alter publication supabase_realtime add table likes;
alter publication supabase_realtime add table views;

-- ============================================================
-- AFTER RUNNING: make yourself owner
--   sign in once via google on the site, then:
--
--   update profiles set role = 'owner' where username = '<your-name>';
--
-- add collaborators the same way with role = 'collaborator'.
-- ============================================================
