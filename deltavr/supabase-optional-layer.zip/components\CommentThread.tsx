"use client";

import { useEffect, useState } from "react";
import { getSupabaseBrowserClient } from "@/lib/supabase/client";
import TimeElapsed from "./TimeElapsed";
import LikeButton from "./LikeButton";

type Comment = {
  id: string;
  content: string;
  created_at: string;
  author_name: string | null;
  author_avatar: string | null;
};

export default function CommentThread({
  postId,
  initialComments,
}: {
  postId: string;
  initialComments: Comment[];
}) {
  const supabase = getSupabaseBrowserClient();
  const [comments, setComments] = useState<Comment[]>(initialComments);
  const [body, setBody] = useState("");
  const [user, setUser] = useState<{ id: string; name: string } | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!supabase) return;
    supabase.auth.getUser().then(async ({ data }) => {
      if (!data.user) return;
      const { data: profile } = await supabase
        .from("profiles")
        .select("username")
        .eq("id", data.user.id)
        .maybeSingle();
      setUser({
        id: data.user.id,
        name: profile?.username ?? data.user.email?.split("@")[0] ?? "anon",
      });
    });

    const channel = supabase
      .channel(`comments-${postId}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "comments",
          filter: `post_id=eq.${postId}`,
        },
        (payload) => {
          const row: any = payload.new;
          setComments((prev) =>
            prev.some((c) => c.id === row.id)
              ? prev
              : [
                  ...prev,
                  {
                    id: row.id,
                    content: row.content,
                    created_at: row.created_at,
                    author_name: row.author_name ?? "someone",
                    author_avatar: row.author_avatar ?? null,
                  },
                ]
          );
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [supabase, postId]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!supabase || !user || !body.trim()) return;
    setBusy(true);
    const { error } = await supabase.from("comments").insert({
      post_id: postId,
      author_id: user.id,
      content: body.trim(),
      author_name: user.name,
    });
    setBusy(false);
    if (!error) setBody("");
  }

  return (
    <div>
      <div className="section-label">
        <span className="red-dot" />
        <span>discussion // {comments.length}</span>
      </div>

      {user ? (
        <form className="comment-form" onSubmit={submit}>
          <textarea
            value={body}
            onChange={(e) => setBody(e.target.value)}
            placeholder={`commenting as ${user.name}…`}
          />
          <div style={{ display: "flex", justifyContent: "flex-end", marginTop: 10 }}>
            <button className="btn btn-black" disabled={busy || !body.trim()}>
              {busy ? "sending…" : "post comment"}
            </button>
          </div>
        </form>
      ) : (
        <div className="empty-note">
          sign in with google (top right → settings area) to comment.
          <br />
          anyone signed in can comment + like. views are counted for everyone.
        </div>
      )}

      <div style={{ marginTop: 24 }}>
        {comments.length === 0 ? (
          <div className="empty-note">no comments yet — be the first.</div>
        ) : (
          comments.map((c) => (
            <div className="comment" key={c.id}>
              <div className="comment-head">
                <span>
                  @{c.author_name ?? "anon"} ·{" "}
                  <TimeElapsed from={c.created_at} className="" />
                </span>
                <LikeButton targetType="comment" targetId={c.id} initialCount={0} />
              </div>
              <div className="comment-body">{c.content}</div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
