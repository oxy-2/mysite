"use client";

import { useEffect, useRef } from "react";
import { getSupabaseBrowserClient } from "@/lib/supabase/client";

export default function ViewCounter({
  targetType,
  slug,
}: {
  targetType: "post" | "page";
  slug: string;
}) {
  const supabase = getSupabaseBrowserClient();
  const counted = useRef(false);

  async function getSessionId(): Promise<string> {
    try {
      let sid = localStorage.getItem("oxy_view_session");
      if (!sid) {
        sid = crypto.randomUUID();
        localStorage.setItem("oxy_view_session", sid);
      }
      return sid;
    } catch {
      return "anon";
    }
  }

  useEffect(() => {
    if (!supabase || counted.current) return;

    (async () => {
      const session_id = await getSessionId();

      // record view (unique per session via upsert on conflict)
      await supabase.from("views").upsert(
        { target_type: targetType, target_id: slug, session_id },
        { onConflict: "target_type,target_id,session_id" }
      );

      // subscribe to count updates
    })();

    const channel = supabase
      .channel(`views-${targetType}-${slug}`)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "views",
          filter: `target_id=eq.${slug}`,
        },
        () => refresh()
      )
      .subscribe();

    async function refresh() {
      const { count } = await supabase!
        .from("views")
        .select("*", { count: "exact", head: true })
        .match({ target_type: targetType, target_id: slug });
      setViews(count ?? 0);
    }

    function setViews(n: number) {
      const el = document.getElementById(`views-${slug}`);
      if (el) el.textContent = `${n} views`;
    }

    refresh();
    counted.current = true;

    return () => {
      supabase?.removeChannel(channel);
    };
  }, [supabase, targetType, slug]);

  return <span id={`views-${slug}`}>— views</span>;
}
