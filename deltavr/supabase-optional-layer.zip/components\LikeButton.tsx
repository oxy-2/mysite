"use client";

import { useEffect, useState } from "react";
import { getSupabaseBrowserClient } from "@/lib/supabase/client";

type Props = {
  targetType: "post" | "comment";
  targetId: string;
  initialCount: number;
};

export default function LikeButton({ targetType, targetId, initialCount }: Props) {
  const supabase = getSupabaseBrowserClient();
  const [count, setCount] = useState(initialCount);
  const [liked, setLiked] = useState(false);
  const [userId, setUserId] = useState<string | null>(null);

  useEffect(() => {
    if (!supabase) return;
    supabase.auth.getUser().then(({ data }) => setUserId(data.user?.id ?? null));
    // did this user already like it?
    supabase.auth.getUser().then(async ({ data }) => {
      if (!data.user) return;
      const { data: existing } = await supabase
        .from("likes")
        .select("id")
        .match({
          user_id: data.user.id,
          target_type: targetType,
          target_id: targetId,
        })
        .maybeSingle();
      if (existing) setLiked(true);
    });
  }, [supabase, targetType, targetId]);

  async function toggle() {
    if (!supabase) return;
    if (!userId) {
      alert("sign in to like things");
      return;
    }
    if (liked) {
      setLiked(false);
      setCount((c) => Math.max(0, c - 1));
      await supabase
        .from("likes")
        .delete()
        .match({ user_id: userId, target_type: targetType, target_id: targetId });
    } else {
      setLiked(true);
      setCount((c) => c + 1);
      await supabase.from("likes").insert({
        user_id: userId,
        target_type: targetType,
        target_id: targetId,
      });
    }
  }

  return (
    <button
      className={`like-btn${liked ? " liked" : ""}`}
      onClick={toggle}
      aria-label="like"
    >
      <span>{liked ? "♥" : "♡"}</span>
      <span>{count}</span>
    </button>
  );
}
