import { NextResponse } from "next/server";
import { getSupabaseServerClient } from "@/lib/supabase/server";
import { BASE_PATH } from "@/lib/site";

export async function GET(request: Request) {
  const { searchParams, origin } = new URL(request.url);
  const code = searchParams.get("code");

  if (code) {
    const supabase = await getSupabaseServerClient();
    if (supabase) {
      await supabase.auth.exchangeCodeForSession(code);

      // ensure a profile row exists for the new user
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (user) {
        await supabase.from("profiles").upsert(
          {
            id: user.id,
            username:
              user.email?.split("@")[0] ?? `user-${user.id.slice(0, 8)}`,
            role: "viewer",
            avatar_url: user.user_metadata?.avatar_url ?? null,
          },
          { onConflict: "id", ignoreDuplicates: true }
        );
      }
    }
  }

  return NextResponse.redirect(`${origin}${BASE_PATH}/updates`);
}
